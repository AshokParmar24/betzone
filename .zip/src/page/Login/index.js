import React from "react";
import InputText from "../../components/Input/InputText";
import PrimaryButton from "../../components/Button/PrimaryButton";
import { useNavigate } from "react-router-dom-v6";

const Login = () => {
  const navigate = useNavigate();
  return (
    <div className="flex justify-center items-center h-screen">
      <div className="bg-black-50 text-white-50 w-[402px] py-10 pl-5 pr-7">
        <div className="text-lg pb-5 font-bold">User Login</div>
        <div className="flex flex-col gap-5">
          <InputText label="Email" placeholder="Enter Email" name="email" />
          <InputText
            label="Password"
            placeholder="Enter Password"
            name="password"
          />
        </div>
        <div className="mt-10">
          <PrimaryButton
            className="w-full"
            text="Login"
            type="submit"
            onClick={() => {
              navigate("/dashboard");
            }}
          />
        </div>
      </div>
    </div>
  );
};
export default Login;
