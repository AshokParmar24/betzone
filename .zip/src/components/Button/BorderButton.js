import React from "react";

const BorderButton = ({ text, className, onClick }) => {
  return (
    <button
      className={`border border-solid border-white-100 text-base bg-black-50 font-bold text-white-100 h-12 cursor-pointer ${className}`}
      onClick={onClick}
    >
      {text}
    </button>
  );
};

export default BorderButton;
