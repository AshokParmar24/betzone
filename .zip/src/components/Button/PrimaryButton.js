import React from "react";
const PrimaryButton = ({ text, className, onClick }) => {
  return (
    <button
      className={`rounded-none border-none text-base font-bold text-white bg-orange-50  h-12 cursor-pointer ${className}`}
      onClick={onClick}
    >
      {text}
    </button>
  );
};
export default PrimaryButton;
