import { FiX } from "react-icons/fi";
export const Icon = ({
  size = 18,
  option,
  color = "white",
  className,
  onClick,
}) => {
  const extraProps = {
    size,
    color,
    className,
    onClick,
  };
  switch (option) {
    case "CANCEL":
      return <FiX {...extraProps} />;
    default:
      return null;
  }
};
