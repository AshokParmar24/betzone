import React from "react";

const InputText = ({ label, placeholder }) => {
  return (
    <div>
      <div className="text-sm font-thin pb-1">{label}</div>
      <input
        className="h-12 rounded-none w-full border-none text-base focus:outline-none"
        placeholder={placeholder}
      />
    </div>
  );
};
export default InputText;
