import React from "react";
import { Route, Navigate, Routes, BrowserRouter } from "react-router-dom-v6";
import Login from "../page/Login";
import Dashboard from "../page/Dashboard";
const AppRouter = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="*" element={<Navigate to="/login" />} />
        <Route path="/login" element={<Login />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    </BrowserRouter>
  );
};

export default AppRouter;
