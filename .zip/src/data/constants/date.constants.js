export const DateFormats = {
  DATE_ISO: "DD/MM/YYYY",
};
