/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    extend: {
      colors: {
        black: {
          50: "#242421",
          100: "#1D1D1B",
          200: "#1a1a1a",
          dark: "#1D1D1B",
          chalk: "#292D32",
        },
        white: {
          50: "#FFFFFF",
          100: "#ffffff66",
        },
        grey: {
          50: "#575756",
          100: "#393939",
          200: "#333332",
          300: "#2C2C2A",
          400: "#242421",
        },
        orange: {
          50: "#EB6708",
          100: "#E83737",
          200: "#eb670833",
          300: "#e83737",
          400: "#e8373733",
        },
      },
    },
  },
  plugins: [],
};
